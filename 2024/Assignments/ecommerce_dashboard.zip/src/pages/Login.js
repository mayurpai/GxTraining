import React, { useState } from 'react';
import { useCookies } from 'react-cookie';
import { toast } from 'react-toastify';

const Login = () => {
  const [username, setUsername] = useState('');
  const [cookies, setCookies] = useCookies(['username']);

  const handleLogin = () => {
    if (username.trim()) {
      setCookies('username', username.trim());
      toast.success('Login successful!');
      window.location.href = '/products';
    } else {
      toast.error('Please enter a valid username');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 to-blue-300 px-4">
      <div className="w-full max-w-md">
        <div className="bg-white shadow-2xl rounded-2xl border border-gray-200 p-8 space-y-6">
          <h2 className="text-3xl font-bold text-center text-blue-600 mb-6">
            Welcome Back
          </h2>
          <div className="space-y-4">
            <input 
              type="text" 
              placeholder="Enter your username" 
              value={username} 
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
            />
            <button 
              onClick={handleLogin}
              className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transform hover:scale-105"
            >
              Login
            </button>
          </div>
          <p className="text-center text-gray-500 text-sm">
            Enter a username to continue
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;