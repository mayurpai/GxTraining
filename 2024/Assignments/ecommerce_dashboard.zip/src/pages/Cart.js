import React, { useContext, useEffect } from 'react';
import { useCookies } from 'react-cookie';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { CartContext } from '../context/CartContext';

const CartItem = ({ item, onDecrease, onIncrease, onRemove }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-4 flex items-center space-x-4">
      <div className="w-24 h-24 flex items-center justify-center bg-gray-100 rounded-lg p-2">
        <img
          src={item.image}
          alt={item.title}
          className="max-h-full max-w-full object-contain"
        />
      </div>

      <div className="flex-grow">
        <h3 className="text-lg font-semibold line-clamp-2">{item.title}</h3>
        <p className="text-gray-600">${item.price.toFixed(2)} each</p>
      </div>

      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <button
            onClick={onDecrease}
            className="bg-gray-200 text-gray-700 w-8 h-8 rounded-full flex items-center justify-center hover:bg-gray-300"
          >
            -
          </button>
          <span className="text-lg font-semibold">{item.count}</span>
          <button
            onClick={onIncrease}
            className="bg-gray-200 text-gray-700 w-8 h-8 rounded-full flex items-center justify-center hover:bg-gray-300"
          >
            +
          </button>
        </div>

        <div className="text-lg font-semibold w-20 text-right">
          ${(item.price * item.count).toFixed(2)}
        </div>

        <button
          onClick={onRemove}
          className="text-red-500 hover:text-red-700"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
          </svg>
        </button>
      </div>
    </div>
  );
};

const Cart = () => {
  const { cart, removeFromCart, decreaseQuantity, dispatch, total } = useContext(CartContext);
  const [cookies] = useCookies(['username']);
  const navigate = useNavigate();

  useEffect(() => {
    if (!cookies.username) {
      toast.error('Please login to view your cart');
      navigate('/login');
    }
  }, [cookies.username, navigate]);

  if (!cookies.username) {
    return null;
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <h2 className="text-4xl font-bold text-center mb-12 text-blue-600">
        Your Cart
      </h2>

      {Object.keys(cart).length === 0 ? (
        <div className="text-center py-16 bg-white rounded-xl shadow-lg">
          <p className="text-2xl text-gray-500">Your cart is empty</p>
          <button
            onClick={() => navigate('/products')}
            className="mt-4 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Shop Now
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {Object.values(cart).map(item => (
            <CartItem
              key={item.id}
              item={item}
              onDecrease={() => decreaseQuantity(item)}
              onIncrease={() => dispatch({ type: 'ADD_TO_CART', payload: item })}
              onRemove={() => {
                toast.success(`${item.title} deleted successfully!`);
                removeFromCart(item.id)}
              }
            />
          ))}

          <div className="bg-white rounded-xl shadow-lg p-6 flex justify-between items-center">
            <h3 className="text-2xl font-bold">Total</h3>
            <div className="text-3xl font-bold text-blue-600">
              ${total.toFixed(2)}
            </div>
          </div>

          <div className="text-center">
            <button
              className="bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition-colors text-lg font-semibold"
            >
              Proceed to Checkout
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
