import React from 'react';
import { Link } from 'react-router-dom';
import { useCookies } from 'react-cookie';

const Header = () => {
  const [cookies, setCookies, removeCookies] = useCookies(['username']);

  const handleLogout = () => {
    removeCookies('username');
    window.location.href = '/login';
  };

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link 
          to="/products" 
          className="text-3xl font-bold text-blue-600 hover:text-blue-800 transition-colors"
        >
          E-Commerce
        </Link>
        
        <nav className="flex items-center space-x-6">
          <Link 
            to="/products" 
            className="text-gray-700 hover:text-blue-600 font-medium transition-colors"
          >
            Products
          </Link>
          
          <Link 
            to="/cart" 
            className="text-gray-700 hover:text-blue-600 font-medium transition-colors"
          >
            Cart
          </Link>
          
          {cookies.username ? (
            <div className="flex items-center space-x-4">
              <span className="text-gray-700">
                Welcome, <span className="font-semibold text-blue-600">{cookies.username}</span>
              </span>
              <button 
                onClick={handleLogout}
                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors"
              >
                Logout
              </button>
            </div>
          ) : (
            <Link 
              to="/login" 
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Login
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Header;