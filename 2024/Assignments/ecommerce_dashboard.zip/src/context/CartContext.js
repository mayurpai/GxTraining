import React, { createContext, useReducer, useEffect, useState } from 'react';
import { useCookies } from 'react-cookie';

const initialState = {};

const cartReducer = (state, action) => {
  switch (action.type) {
    case 'ADD_TO_CART': {
      const { id } = action.payload;
      const currentCount = state[id] ? state[id].count : 0;
      return {
        ...state,
        [id]: {
          ...action.payload,
          count: currentCount + 1
        }
      };
    }
    case 'REMOVE_FROM_CART': {
      const { [action.payload]: removedItem, ...remainingItems } = state;
      return remainingItems;
    }
    case 'DECREASE_QUANTITY': {
      const { id } = action.payload;
      const currentItem = state[id];
      if (currentItem.count > 1) {
        return {
          ...state,
          [id]: {
            ...currentItem,
            count: currentItem.count - 1
          }
        };
      }
      const { [id]: removedItem, ...remainingItems } = state;
      return remainingItems;
    }
    case 'RESET_CART':
      return initialState;
    case 'SET_CART':
      return action.payload;
    default:
      return state;
  }
};

export const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cookies] = useCookies(['username']);
  const [currentUsername, setCurrentUsername] = useState(cookies.username || 'guest');
  
  const storedCartKey = `cart_${currentUsername}`;
  const initialStoredCart = JSON.parse(localStorage.getItem(storedCartKey)) || {};

  const [cart, dispatch] = useReducer(cartReducer, initialStoredCart);

  // Effect to reset cart when username changes
  useEffect(() => {
    // Check if username has changed
    if (currentUsername !== (cookies.username || 'guest')) {
      // Get the cart for the new user
      const newUserCartKey = `cart_${cookies.username || 'guest'}`;
      const newUserCart = JSON.parse(localStorage.getItem(newUserCartKey)) || {};
      
      // Set the cart for the new user
      dispatch({ type: 'SET_CART', payload: newUserCart });
      
      // Update the current username
      setCurrentUsername(cookies.username || 'guest');
    }
  }, [cookies.username]);

  // Effect to persist cart to localStorage
  useEffect(() => {
    localStorage.setItem(storedCartKey, JSON.stringify(cart));
  }, [cart, storedCartKey]);

  const total = Object.values(cart).reduce((acc, item) => 
    acc + (item.price * item.count), 0);

  return (
    <CartContext.Provider value={{ 
      cart, 
      dispatch, 
      total,
      removeFromCart: (id) => dispatch({ type: 'REMOVE_FROM_CART', payload: id }),
      decreaseQuantity: (product) => dispatch({ type: 'DECREASE_QUANTITY', payload: product })
    }}>
      {children}
    </CartContext.Provider>
  );
};